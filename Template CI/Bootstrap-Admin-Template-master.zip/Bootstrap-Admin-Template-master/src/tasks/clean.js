module.exports = {
  dist: '<%= config.dest %>',
  build: 'build'
};
